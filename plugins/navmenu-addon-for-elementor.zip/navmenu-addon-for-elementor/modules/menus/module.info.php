<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

return [
	'title'              => __( 'Menus', 'navmenu-addon-for-elementor' ),
	'required'           => true,
	'default_activation' => true,
];
