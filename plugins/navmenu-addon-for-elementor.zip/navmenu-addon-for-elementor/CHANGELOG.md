
 ### v1.1.2 - 2017-11-27 
 **Changes:** 
 * Fix TGM strings for recommended plugins.
 
 ### v1.1.1 - 2017-11-16 
 **Changes:** 
 * Add recommendation for Elementor Addons & Widgets. 
* Tested up to 4.9.
 
 ### v1.1.0 - 2017-09-28 
 **Changes:** 
 * Added Themeisle SDK.
* Added Continuous Integration.
* Changed contributors.
 
