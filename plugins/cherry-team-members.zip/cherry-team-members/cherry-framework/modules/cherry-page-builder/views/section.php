<?php
/**
 * View for section of settings
 *
 * @package  TM Real Estate
 * @author   Guriev Eugen & Sergyj Osadchij
 * @license  GPL-2.0+
 */
?>
<div class="description"><?php echo $__data['description'] ?></div>
